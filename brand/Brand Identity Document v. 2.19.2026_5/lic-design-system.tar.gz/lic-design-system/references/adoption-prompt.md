# Codex Adoption Prompt Templates

Use these prompts in the target repository after copying this skill folder.

## One-Shot Adoption Prompt

```text
Use the lic-design-system skill in this repo.

Goal: retrofit the app to the LIC design system.

Do this:
1. Audit the current UI stack and shared component layer.
2. Install LIC design tokens (color, typography, spacing, borders) and wire them into global styles/theme.
3. Refactor base primitives (button, input, select, textarea, badge, card, table, modal, alert, toast, tabs, pagination) to match the LIC UI kit rules.
4. Apply LIC interaction doctrine (focus, loading, validation, confirmation, accessibility, anti-pattern removal).
5. For AI surfaces, apply LIC command-surface + provenance rules.
6. If GP-01 screens exist, align them with GP-01 flow standards.
7. Return a compliance report with: changed files, remaining gaps, and recommended follow-ups.

Constraints:
- Keep corners square by default.
- Do not introduce colors outside LIC tokens.
- Avoid decorative motion and startup-style visual language.
- Preserve or improve accessibility while refactoring.
```

## Incremental Adoption Prompt

```text
Use the lic-design-system skill.

Phase 1 only: set up global LIC tokens, typography, and layout primitives without changing page-specific business logic.
Then list exact component files to tackle in phase 2.
```

## Compliance Review Prompt

```text
Use the lic-design-system skill to run a compliance review only.
Do not redesign yet.
Identify violations against tokens, component rules, interaction doctrine, and AI interaction standards.
Prioritize findings by severity and include file references.
```
